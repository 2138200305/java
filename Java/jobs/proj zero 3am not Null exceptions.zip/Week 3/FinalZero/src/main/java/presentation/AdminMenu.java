package presentation;

import util.AppState;
import util.InputProcessor;

public class AdminMenu implements Menu {

	@Override
 public LoginMenu display() {
 	InputProcessor ip = InputProcessor.getInstance();
 	int userSelection = ip.intPrompt(0, 3, "Welcome " + AppState.getActiveUser().getUserName(), "View unapproved accounts","View all accounts" ,  "View specific account");
 	switch(userSelection) {
 	case 0 : //exit the menu
 		return null;
 	case 1 : //view unapproved accounts
 		
 		break;
 	case 2 : //view all accounts
 		break;
 	case 3 : //view specific account
 		break;
 	}
     return null;
 }


// public String adminMenu() {
//     String selection = "x";
//     System.out.println("Press:");
//     System.out.println("w - to withdraw");
//     System.out.println("d - to deposit");
//     System.out.println("t - to transfer");
//     System.out.println("c - to cancel an account");
//     System.out.println("v - to view all customer information");
//     System.out.println("a - to deny or approve an account");
//     System.out.println("x to Exit");
//     selection = infoAccept.nextLine().trim();
//     return selection;
// }
//
// public String employeeMenu() {
//     String selection = "x";
//     System.out.println("Press:");
//     System.out.println("w - to withdraw");
//     System.out.println("d - to deposit");
//     System.out.println("t - to transfer");
//     System.out.println("v - to view all customer information");
//     System.out.println("a - to deny or approve an account");
//     System.out.println("x to Exit");
//     selection = infoAccept.nextLine().trim();
//     return selection;
// }
}
