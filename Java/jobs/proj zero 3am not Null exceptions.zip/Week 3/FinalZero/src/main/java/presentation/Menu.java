package presentation;

public interface Menu {
    Menu display();
}
