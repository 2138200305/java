package data;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.ArrayList;
import java.util.List;

import models.Account;
import models.User;

public class AccountDAO {

    private static AccountDAO ad;

    // private constructor to force use of
    // getInstance() to create Singleton object

    public static AccountDAO getInstance()
    {
        if (ad ==null)
            ad = new AccountDAO();
        return ad;
    }
//TODO method to get ALL accounts
	public List<Account> getAllAccounts(){
	List<Account> accounts = sqlPrepRequest(null, null, "SELECT * FROM account");	
	return accounts;		
	}
	
	public Account getByUserName(User user) {
		String un = user.getUserName();
		String sql = "SELECT * FROM ACCOUNT JOIN JUNCTION ON ACCOUNT.ACCOUNT_ID = JUNCTION.ACCOUNT_ID JOIN BANKUSER ON JUNCTION.USER_NAME = BANKUSER.USER_NAME WHERE BANKUSER.USER_NAME = ";
		sql += un;
		List<Account> la = sqlPrepRequest(null, null, sql);
		la.toString();
		return la.get(0);
	}
    
	//TODO method to get all accounts for AppState.activeUser()    
    // TODO method to update AppState.activeAccount
    

 
	private List<Account> sqlPrepRequest(Account acc, String noAccount, String sql) {
        List<Account> accounts = null;
        try (Connection conn = ConnectionFactory.getInstance().getConnection()) {

            conn.setAutoCommit(false);

           PreparedStatement pstmt = conn.prepareStatement(sql);
//            e.g. sql may be "SELECT * FROM users WHERE username = ?"
 
          //  if (acc != null && noAccount == null) {
            	 if (acc != null && noAccount == null) {
                pstmt.setInt(1, acc.getAccNum());
                pstmt.setDouble(2, acc.getBalance());
            } else if (acc == null && noAccount != null) {
                
           pstmt.setString(1,noAccount);
            }

            pstmt.execute(); //This is where our SQL statement actually fires.

            if (pstmt.executeUpdate() != 0) conn.commit();

            accounts = mapResultSet(pstmt.executeQuery());

        } catch (SQLIntegrityConstraintViolationException sicve) {
            System.out.println("SQL INTEGRITY EXCEPTION");
        } catch (SQLException e) {
            System.out.println("SQL GENERIC EXCEPTION");
        }
        return accounts;
    }

	private List<Account> mapResultSet(ResultSet rs) throws SQLException {
		List<Account> returnVar = new ArrayList<Account>(); {
		};
		
		while (rs.next()) {
			int account_id = rs.getInt(1);
			int balance = rs.getInt(2);
				returnVar.add(new Account(account_id, balance));
		}
		return returnVar;
	}
}
