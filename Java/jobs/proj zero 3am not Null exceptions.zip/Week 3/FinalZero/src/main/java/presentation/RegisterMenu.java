package presentation;

import models.User;
import util.InputProcessor;

public class RegisterMenu implements Menu {

	public static void main (String[] args)
	{
		new RegisterMenu();
		
	}
	public RegisterMenu() {
		display();
		
	}
	
	@Override
	public Menu display() {
		
		
		InputProcessor ip = InputProcessor.getInstance();
		
		String tempFirst = ip.stringPrompt(2, 25, "Enter your first name");
		String tempLast = ip.stringPrompt(2, 25, "Enter your last name");
		String tempUser = ip.stringPrompt(2, 25, "Enter your Username");
		String tempPass = ip.stringPrompt(2, 25, "Enter your Password");

		User nUser = new User( tempUser,tempPass, tempFirst,tempLast);
		
		System.out.println("Thank you your account is pending approval for the next 24 hours");
		return null;
	}

}
