package util;

import presentation.HomeMenu;

public class Driver {

	public static void main(String[] args) {
	new HomeMenu();
	}

}
