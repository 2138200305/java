package models;

import java.util.List;


public class Account {
	// ==================FIELDS==================
	private int AccNum;
	private double balance;
	private List<User> activeCustomers;
	private String userLevel; // User -- 2 Customer -- 3 Employee -- 4 Admin
								// Users have Accounts in pending mode - Customers have Accounts, but
								// Employees/Admins can view all
	// ==================CONSTRUCTORS==================

	public Account(int accNum, double accBalance) {
		AccNum = accNum;
		balance = accBalance;
	}

	// ==================GETTERS AND SETTERS==================
	public int getAccNum() {
		return AccNum;
	}

	public List<User> getAllUsers(){ 
    	return this.activeCustomers;
    			}


	public void setAccNum(int accNum) {
        AccNum = accNum;
    }

	public double getBalance() {
        return balance;
    }

	public void setBalance(double balance) {
		this.balance = balance;
	}
}
