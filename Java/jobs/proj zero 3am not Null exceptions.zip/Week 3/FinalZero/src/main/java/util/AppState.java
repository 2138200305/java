package util;

import models.Account;
import models.User;

public class AppState {
    private static User activeUser;
    private static Account loadedAccount;
    private static User loadedUser;

    public static User getLoadedUser() {
		return loadedUser;
	}

	public static void setLoadedUser(User user) {
		AppState.loadedUser = user;
	}

	public static Account getLoadedAccount() {
		return loadedAccount;
	}

	public static void setLoadedAccount(Account loadedAccount) {
		
		AppState.loadedAccount = loadedAccount;
	}

	private static Account activeAccount;

    public static User getActiveUser() {
        return activeUser;
    }

    public static void setActiveUser(User activeUser) {
        AppState.activeUser = activeUser;
    }

    public static Account getActiveAccount() {
        return activeAccount;
    }

    public static void setActiveAccount(Account activeAccount) {
        AppState.activeAccount = activeAccount;
    }
}
