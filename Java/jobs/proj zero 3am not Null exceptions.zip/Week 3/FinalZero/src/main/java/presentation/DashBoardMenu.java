package presentation;

import models.User;
import service.AccountServices;
import util.AppState;
import util.InputProcessor;

public class DashBoardMenu implements Menu {

	public DashBoardMenu() {
		this.display();
	}

	InputProcessor ip = InputProcessor.getInstance();
	AccountServices as;

	@Override
	public Menu display() {
		System.out.println("Welcome to the Dashboard");
		// Debuggin
		User activeUser = AppState.getActiveUser();
		activeUser.toString();
		if (activeUser.getUserLevel().equals("customer")) {

			// Show user a list of their accounts and have them select from amongst them to
			// set the
			// active account for us to manipulate later in the switch statement.

			int userChoice = ip.intPrompt(0, 3, activeUser.getUserName() + "'s Dashboard:", "Withdraw", "Deposit",
					"Transfer");
			switch (userChoice) {
			case 0:
				return null;
			case 1:
				as.Withdraw(AppState.getActiveAccount());
				AppState.getActiveAccount().toString();
				break;
			case 2:
				as.Deposit(AppState.getActiveAccount());
				AppState.getActiveAccount().toString();
				break;
			case 3:
				ip.doublePrompt(0, 100000, "How much is the transaction?");
				AppState.getActiveAccount().toString();
				break;
			}

		}
		return null;
	}
}
