package models;

import java.util.List;

public class User {

    //==================FIELDS===================================
    private String userName;
    private String userLevel;
    private String password;
    private String userFirstName; 
    private String userLastName;
    private List<Account> activeUserAccounts;

    //==================CONSTRUCTORS===================================
    public User(String userName, String userLevel, String password) {
        this.userName = userName;
        this.userLevel = userLevel;
        this.password = password;
    }

    
   //this constructor is only called when creating a new account from the RegisterMenu
    public User(String tempUser, String tempPass, String tempFirst, String tempLast) {
    	this.userLevel = "user";
    	this.userFirstName = tempFirst;
    	this.userLastName = tempLast;
    	this.userName= tempUser;
    	this.password=tempPass;
    	//TODO enter newly created user into database
    }

  
    //constructor only called from the UserDAO when loading accounts //all variables are appended with 2 to prevent variable shadowing.
    public User(String userName2, String password2, String userFirstName2, String userLastName2, String userLevel2) {
    	this.userLevel = userLevel2;
    	this.userFirstName = userFirstName2;
    	this.userLastName = userLastName2;
    	this.userName= userName2;
    	this.password=password2;
	}

	//==================GETTERS AND SETTERS===================================
    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserLevel() {
        return userLevel;
    }

    public void setUserLevel(String userLevel) {
        this.userLevel = userLevel;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public List<Account> getActiveUserAccounts() {
        return activeUserAccounts;
    }

    public void setActiveUserAccounts(List<Account> activeUserAccounts) {
        this.activeUserAccounts = activeUserAccounts;
    }

    
    
    
	public String getUserFirstName() {
		return userFirstName;
	}


	public void setUserFirstName(String userFirstName) {
		this.userFirstName = userFirstName;
	}


	public String getUserLastName() {
		return userLastName;
	}


	public void setUserLastName(String userLastName) {
		this.userLastName = userLastName;
	}


	@Override
	public String toString() {
		return "User [userName=" + userName + ", userLevel=" + userLevel + ", password=" + password + ", userFirstName="
				+ userFirstName + ", userLastName=" + userLastName + ", activeUserAccounts=" + activeUserAccounts + "]";
	}
}
