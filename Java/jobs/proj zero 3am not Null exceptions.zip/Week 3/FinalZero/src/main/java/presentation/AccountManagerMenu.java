package presentation;

import java.util.List;

import data.UserDAO;
import models.Account;
import models.User;
import util.AppState;
import util.InputProcessor;

public class AccountManagerMenu implements Menu {
	int userChoice = 0;

//employee or admin user lever
	public void listUsers(Account acc) {
		for (User u : AppState.getActiveAccount().getAllUsers())
			System.out.println(u.toString());

		// if(AppState.getActiveUser().getUserLevel.equals("admin") ));

	}

//	userChoice = ip.intPrompt(0,5,"Employee Console:", )
//"What is the customer's username"
//userChoice = ip.intPrompt(1, 3, "Welcome " + AppState.getActiveUser().getUserName() + "!\nWhat would you like to do?\n0 to exit.", "Withdraw", "Deposit", "Transfer");
	@Override
	public Menu display() {
		InputProcessor ip = InputProcessor.getInstance();
		List<Account> thisUsersAccounts = null;

		while (true) {
			if (AppState.getActiveUser().getUserLevel().equals("employee")) {
				userChoice = ip.intPrompt(0, 5,
						"Welcome " + "Employee Console:" + "What would you like to do?\n0 to exit.", "Withdraw",
						"Deposit", "Transfer", "View All accounts");

			} else if (AppState.getActiveUser().getUserLevel().equals("admin")) {
				userChoice = ip.intPrompt(0, 5,
						"Welcome " + "Admin Console:" + AppState.getActiveUser().getUserName()
								+ "!\nWhat would you like to do?\n0 to exit.",
						"Withdraw", "Deposit", "Transfer", "View All accounts", "Approve Pending Accounts",
						"Cancel Accounts");
				switch (userChoice) {

				case 0:
					return null;
				case 1:
					getUserAndAccounts();
					break;
				case 2:
					getUserAndAccounts();
					break;
				case 3:
					getUserAndAccounts();
					break;
				case 4:
					UserDAO ud = UserDAO.getInstance();
					List<User> allUsers = ud.getAllUserNames();
					printAllUsers(allUsers);
					break;
				case 5:
					ip.stringPrompt(5, 25, "Show list of all accounts pending approval");

					break;
				case 6:
					ip.stringPrompt(5, 25, "Enter customer user name");
					break;
				}
			}
			return null;
		}
	}

	private void printAllUsers(List<User> allUsers) {
		for (int i = 0; i < allUsers.size(); i++) {
			System.out.println(allUsers.get(i).getUserLevel() + "     " + allUsers.get(i + 1).getUserLevel());
			i++;
		}
	}

	private List<Account> getUserAndAccounts() {
		InputProcessor ip = InputProcessor.getInstance();
		AppState.setLoadedUser(UserDAO.getInstance().getByUserName(
				ip.stringPrompt(5, 25, "Welcome to the Account Management Console. Please provide a username")));
		return AppState.getLoadedUser().getActiveUserAccounts();
	}

	private User getUser(String customerUserName) {	
		UserDAO ud = new UserDAO();
		ud.getByUserName(customerUserName);
		return ud.getByUserName(customerUserName);

	}

}
