// Variable declaration
let myVariable;

// myVariable is declared but is not defined

console.log(myVariable); // undefined

myVariable = 10;

console.log(myVariable); // 10

// declaration + assignment
let x = 20;

console.log(x); // 20