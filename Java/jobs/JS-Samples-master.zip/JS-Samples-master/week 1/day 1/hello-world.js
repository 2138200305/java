// <---- Comment 
/*
    Comment Block
    Comments are important!  We should write lots of comments!
    If someone can't understand your code, it might be code, but it 
        might comments too!
*/


console.log('Hello World');

// We can execute a JavaScript file using node, by using the commandline operation
// node <file-name>