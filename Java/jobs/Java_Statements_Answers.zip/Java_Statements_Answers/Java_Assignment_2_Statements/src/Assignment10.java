
public class Assignment10 {

	public static void main(String[] args) {
		double[] a = {1.1,2.2,3.3,4.4,5.5,6.6,7.7,8.8,9.9,10.0};
		
		for (int i = 0; i < a.length; i++){
			System.out.println(a[i]);
		}
	}
}
