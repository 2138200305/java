
public class Assignment5 {

	public static void main(String[] args) {
		int x = 55;
		
		if (x == 3){
			System.out.println("x is equal to 3");
		}else {
			System.out.println("x is NOT equal to 3");
		}
	}
}
