
public class Assignment2 {

	public static void main(String[] args) {
		int x = 5;
		
		if (x > 3){
			System.out.println("x is greater than 3");
		}
	}
}
