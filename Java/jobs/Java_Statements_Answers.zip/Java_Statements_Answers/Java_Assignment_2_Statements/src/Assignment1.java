
public class Assignment1 {

	public static void main(String[] args) {
		int x = 5;
		
		if (x %2 == 0){
			System.out.println("The number is even");
		}
	}
}
