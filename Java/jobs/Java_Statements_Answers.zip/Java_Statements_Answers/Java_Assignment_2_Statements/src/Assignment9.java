
public class Assignment9 {

	public static void main(String[] args) {
		int i = 0;
		while (i < 7){
			System.out.println("In loop");
			i++;
		}
	}
}
