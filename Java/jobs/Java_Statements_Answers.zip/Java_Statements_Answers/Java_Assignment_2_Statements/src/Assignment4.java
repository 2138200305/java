
public class Assignment4 {

	public static void main(String[] args) {
		int x = 3;

		if (x == 3) {
			System.out.println("x is equal to 3");
		}

	}
}
