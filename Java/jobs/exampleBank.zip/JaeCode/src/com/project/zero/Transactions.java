package com.project.zero;

public class Transactions {

	public Double deposit(Double balance, Double transactionAmount) {
		balance = +transactionAmount;
		return balance;
	}

	public Double withdraw(Double balance, Double transactionAmount) {
		if (balance > transactionAmount)
			balance -= transactionAmount;
		else {
			System.out.println(
					"withdraw not completed because the transaction amount was greater than that available balance");
		}
		return balance;
	}
}
