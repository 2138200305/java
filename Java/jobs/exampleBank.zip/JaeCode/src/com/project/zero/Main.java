package com.project.zero;

public class Main {

	public static void main(String[] args) {
		User newUser = new User("jaenwawe", "isGreat", "Jae", "Nwawe", "admin");		
		User secondUser = new User();
		User thirdUser = new User("Austin", "panda", "Austin", "Bark");
		
		System.out.println(newUser.toString() + "\n" +  secondUser.toString() + "\n" + thirdUser.toString());
		
	}
}
