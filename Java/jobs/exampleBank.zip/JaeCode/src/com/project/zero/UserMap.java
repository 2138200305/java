package com.project.zero;

import java.util.HashMap;

public class UserMap {

	private HashMap<String, User> mapOfUsers = new HashMap<String, User>();
	
	private UserMap() {}

	
	
	
	
	// getters and setters
	public static HashMap<String, User> getUserMap() {
		return mapOfUsers;
	}
	
}
