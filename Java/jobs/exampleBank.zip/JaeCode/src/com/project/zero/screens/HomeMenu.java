package com.project.zero.screens;

import com.project.zero.StaticScanner;
import com.project.zero.UserMap;

public class HomeMenu {

	public static void display() {
		System.out.println("Welcome to Win-Win! \nPlease enter a username:");
		String response = StaticScanner.getInputString();
		// check the hashMap for the username; if it doesn't exist, create one; if it does, login
		if(UserMap.getUserMap().containsKey(response)) {
			// login
			System.out.println("Please enter a password:");
			
		} else { // userMap does NOT have the username
			// apply for new account
		}
		
		
	}
}
