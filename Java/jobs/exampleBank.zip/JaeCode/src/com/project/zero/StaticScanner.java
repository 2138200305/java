package com.project.zero;

import java.util.Scanner;

public class StaticScanner {

	private static Scanner sc = new Scanner(System.in);
	
	
	public static String getInputString() {
		String input = sc.nextLine();
		if (input.trim() != null) {
			return input;		
		} 
		System.out.println("Error: please enter a valid input");
		return null;
	}
	
	public static int getInputInt() {
		return Integer.parseInt(getInputString());
	}
	
	public static Double getInputDouble() {
		return Double.parseDouble(getInputString());
	}
}
