package com.project.zero;

public class OriginalCode2 {

	public class User {
		static HashMap<String, User> userMap = new HashMap();
		static String clientUserName; // Employees can select User name to modify their account

		String userName;
		String userLevel;
		String password;

		Integer accountNo;
		int counter = 100; // goal make it increment

		// Account info
		// String firstNLastName;
		String[] firstNLastName = { "primaryAccountHolder", "secondaryAccountHolder" };

		String accountHolderTwoName;
		Double userBalance = 0.0;

		Integer employeeID;
		// AccountWTD accountServices = new AccountWTD();

		static User currentUser = new User("almostApplicant", "registered", "guest");
		static StaticScanner infoAccept = new StaticScanner(System.in);
		String response;
		static String userSelection = "x";

		public static void mapToString(User currentUser) {
			System.out.println("\t mapToString(User currentUser) shows userMap entered "
					+ userMap.get(currentUser.userName).firstNLastName[0] + "\n" + "\t " + "userName: "
					+ userMap.get(currentUser.userName).userName + " password: "
					+ userMap.get(currentUser.userName).password + " " + "you are currently "
					+ userMap.get(currentUser.userName).userLevel + " with account "
					+ userMap.get(currentUser.userName).accountNo + " contains "
					+ userMap.get(currentUser.userName).userBalance + "\n");
		}

		public User(String userName, String userLevel, String password) {
			this.userName = userName;
			this.userLevel = userLevel;
			this.password = password;
		}

		public User(String userName, String userLevel, String password, Integer accountNo) {
			this.userName = userName;
			this.userLevel = userLevel;
			this.password = password;

			this.accountNo = accountNo;
			this.firstNLastName[0] = "firstNLastName";
			this.userBalance = 1.00;
		}

		public User(String userName, String userLevel, String password, Integer accountNo, Double accDouble) {
			this.userName = userName;
			this.userLevel = userLevel;
			this.password = password;

			this.accountNo = accountNo;
			this.firstNLastName[0] = "firstNLastName";
			this.userBalance = accDouble;
		}

		public User() {
			this.userName = "EmptyConstructorUserName";
			this.password = "EmptyConstructorPassword";

			this.firstNLastName[0] = "Empty Constructor First User";
			this.firstNLastName[1] = "Empty Constructor Second User";

			this.userLevel = "registered";
			this.accountNo = 4040;
			this.userBalance = 4040.00;
		}

		public User userToCustomer(User applicantUser) {
			System.out.println("What is your name");
			applicantUser.firstNLastName[0] = infoAccept.nextLine();

			applicantUser.accountNo = counter++;
			applicantUser.userLevel = "customer";

			System.out.println("Will you add a second account holder");
			response = infoAccept.nextLine().toLowerCase().trim();
			if (response.contains("yes")) {
				System.out.println("What is their name");
				applicantUser.firstNLastName[1] = infoAccept.nextLine();
			}
			return applicantUser;
		}

		public String customerMenu() {
			String selection = "x";
			System.out.println("\tYour username and password match a current customers");

			System.out.println("Press:");
			System.out.println("w - to withdraw");
			System.out.println("d - to deposit");
			System.out.println("t - to transfer");
			System.out.println("x to Exit");
			selection = infoAccept.nextLine().trim();
			return selection;
		}

		public String employeeMenu() {
			String selection = "x";
			System.out.println("Press:");
			System.out.println("w - to withdraw");
			System.out.println("d - to deposit");
			System.out.println("t - to transfer");
			System.out.println("v - to view all customer information");
			System.out.println("a - to deny or approve an account");
			System.out.println("x to Exit");
			selection = infoAccept.nextLine().trim();
			return selection;
		}

		public String adminMenu() {
			String selection = "x";
			System.out.println("Press:");
			System.out.println("w - to withdraw");
			System.out.println("d - to deposit");
			System.out.println("t - to transfer");
			System.out.println("c - to cancel an account");
			System.out.println("v - to view all customer information");
			System.out.println("a - to deny or approve an account");
			System.out.println("x to Exit");
			selection = infoAccept.nextLine().trim();
			return selection;
		}

		public Double deposit(Double balance, Double transactionAmount) {
			balance = +transactionAmount;
			return balance;
		}

		public Double withdraw(Double balance, Double transactionAmount) {
			if (balance > transactionAmount)
				balance -= transactionAmount;
			else {
				System.out.println(
						"withdraw not completed because the transaction amount was greater than that available balance");
			}
			return balance;
		}

		public static void main(String[] args) {
			User transactionUser;

			userMap.put(currentUser.userName, currentUser);
			mapToString(currentUser);

			currentUser = new User("regular", "customer", "password", 8080, 0.00);
			currentUser.firstNLastName[0] = "regular First User";
			currentUser.firstNLastName[1] = "regular Second User";
			currentUser.userBalance = 4040.00;

			userMap.put(currentUser.userName, currentUser);
			mapToString(currentUser);

			currentUser = new User("adminteller", "admin", "admincode");
			currentUser.firstNLastName[0] = "teller First User";
			currentUser.firstNLastName[1] = "teller Second User";
			currentUser.accountNo = 1111;
			currentUser.userBalance = 000.00;
			userMap.put(currentUser.userName, currentUser);
			mapToString(currentUser);

			currentUser = new User("teller", "employee", "code");
			currentUser.firstNLastName[0] = "teller First User";
			currentUser.firstNLastName[1] = "teller Second User";
			currentUser.accountNo = 1111;
			currentUser.userBalance = 000.00;
			userMap.put(currentUser.userName, currentUser);
			mapToString(currentUser);

			System.out.println("Main - Enter a username");
			String welcomeUserName = infoAccept.nextLine().trim();

			System.out.println("Main - Enter a password");
			String welcomeUserPassword = infoAccept.nextLine().trim();

			if (userMap.containsKey(welcomeUserName)
					& welcomeUserPassword.matches((userMap.get(welcomeUserName)).password)) {
				currentUser = userMap.get(welcomeUserName);
				if (userMap.get(welcomeUserName).userLevel == "customer") {
					System.out.println("\t Username & Password confirmed");
					mapToString(currentUser);
					System.out.println("\tcustomer Menu selection is " + userSelection);
					userSelection = currentUser.customerMenu();
					currentUser = userMap.get(welcomeUserName);
				} else if (userMap.get(currentUser.userName).userLevel == "employee") {
					System.out.println("\tYour username and password match a current employees");
					System.out.println("Welcome WinWin Bank employee \n" + currentUser.userName + " "
							+ userMap.get(currentUser.userName).password);

					mapToString(currentUser);
					System.out.println("\temployee Menu selection is " + userSelection);
					currentUser = userMap.get(currentUser.userName);
					userSelection = currentUser.employeeMenu();
				} else if (userMap.get(currentUser.userName).userLevel == "admin") {
					mapToString(currentUser);
					System.out.println("\tYour username and password match a current admin");
					currentUser = userMap.get(currentUser.userName);
					userSelection = currentUser.adminMenu();
				} else {
					System.out.println("Type apply to apply for a bank account");
					if (infoAccept.nextLine().toLowerCase().contains("apply")) {
						currentUser = currentUser.userToCustomer(currentUser);
						userMap.put(currentUser.userName, currentUser);
						System.out.println("Project 0 - Welcome to WinWin Bank \n" + currentUser.userName + " "
								+ userMap.get(currentUser.userName).password);
						userSelection = currentUser.customerMenu();
						mapToString(currentUser);
					}
				}
			}

			String amount, toClientUserName, fromClientUserName;
			Double transaction;
			Double transactionBalance = 0.00;
			Boolean again = true;

			do {
				switch (userSelection) {
				case "d":
					// Debugging
					System.out.println("\t Selected d");
					mapToString(currentUser);

					System.out.println("\tcustomer Menu selection is " + userSelection);
					if (userMap.get(currentUser.userName).userLevel.equals("admin")
							|| userMap.get(currentUser.userName).userLevel.equals("employee")) {
						mapToString(currentUser);
						System.out.println("What user's account would you like? Enter userName");
						clientUserName = infoAccept.nextLine().toLowerCase().trim();
						// DEBUGGING
						System.out.println("\t" + clientUserName + " clientUserName entered but not entering usermap ");

						transactionUser = userMap.get(clientUserName);
						transactionBalance = transactionUser.userBalance;// store client's balance in buffer

						System.out.println("How much is the transaction?");
						amount = infoAccept.nextLine().toLowerCase().trim();
						transaction = Double.parseDouble(amount);
						// Debugging
						transactionBalance = transactionBalance
								+ currentUser.deposit(userMap.get(clientUserName).userBalance, transaction);
						System.out.println("\t transaction amount entered" + transaction);
						mapToString(userMap.get(transactionUser.userName));
						transactionUser.userBalance = transactionBalance;
						userMap.put(clientUserName, transactionUser);
						mapToString(userMap.get(clientUserName));
					}
					if (userMap.get(currentUser.userName).userLevel == "customer") {
						mapToString(userMap.get(currentUser.userName));
						transactionUser = userMap.get(currentUser.userName);
						transactionBalance = transactionUser.userBalance;
						System.out.println("How much is the transaction?");
						amount = infoAccept.nextLine().toLowerCase().trim();
						transaction = Double.parseDouble(amount);
						transactionBalance += currentUser.deposit(userMap.get(currentUser.userName).userBalance, transaction);
						System.out
						.println("\t transaction amount entered" + transaction + userMap.get(transactionUser.userName));
						transactionUser.userBalance = transactionBalance;
						userMap.put(currentUser.userName, transactionUser);
						mapToString(userMap.get(currentUser.userName));
					}

					break;
				case "w":
					// Debugging
					System.out.println("\t Selected w");
					mapToString(currentUser);
					// Debugging
					System.out.println("\t Selected w");
					mapToString(currentUser);

					System.out.println("\tcustomer Menu selection is " + userSelection);
					if (userMap.get(currentUser.userName).userLevel.equals("admin")
							|| userMap.get(currentUser.userName).userLevel.equals("employee")) {
						mapToString(currentUser);
						System.out.println("What user's account would you like? Enter userName");
						clientUserName = infoAccept.nextLine().toLowerCase().trim();
						// DEBUGGING
						System.out.println("\t" + clientUserName + " clientUserName entered but not entering usermap ");

						transactionUser = userMap.get(clientUserName);
						transactionBalance = transactionUser.userBalance;// store client's balance in buffer

						System.out.println("How much is the transaction?");
						amount = infoAccept.nextLine().toLowerCase().trim();
						transaction = Double.parseDouble(amount);
						// Debugging
						transactionBalance = currentUser.withdraw(userMap.get(clientUserName).userBalance, transaction);
						System.out.println("\t transaction amount entered" + transaction);
						mapToString(userMap.get(transactionUser.userName));
						transactionUser.userBalance = transactionBalance;
						userMap.put(clientUserName, transactionUser);
						mapToString(userMap.get(clientUserName));
					}
					if (userMap.get(currentUser.userName).userLevel == "customer") {
						mapToString(userMap.get(currentUser.userName));
						transactionUser = userMap.get(currentUser.userName);
						transactionBalance = transactionUser.userBalance;
						System.out.println("How much is the transaction?");
						amount = infoAccept.nextLine().toLowerCase().trim();
						transaction = Double.parseDouble(amount);
						transactionBalance = currentUser.withdraw(userMap.get(currentUser.userName).userBalance, transaction);
						System.out
						.println("\t transaction amount entered" + transaction + userMap.get(transactionUser.userName));
						transactionUser.userBalance = transactionBalance;
						userMap.put(currentUser.userName, transactionUser);
						mapToString(userMap.get(currentUser.userName));
					}
					break;
				case "t":
					// Debugging
					System.out.println("\t Selected t");
					mapToString(currentUser);
					// Debugging

					System.out.println("\tcustomer Menu selection is " + userSelection);
					if (userMap.get(currentUser.userName).userLevel.equals("admin")
							|| userMap.get(currentUser.userName).userLevel.equals("employee")) {
						mapToString(currentUser);

						System.out.println("What user's account would you like to transfer from? Enter userName");
						fromClientUserName = infoAccept.nextLine().toLowerCase().trim();
						// DEBUGGING
						mapToString(userMap.get(fromClientUserName));

						transactionUser = userMap.get(fromClientUserName);
						transactionBalance = transactionUser.userBalance;// store client's balance in buffer
						// DEBUGGING

						System.out.println("How much is the transaction?");
						amount = infoAccept.nextLine().toLowerCase().trim();
						transaction = Double.parseDouble(amount);
						// Debugging
						if (transactionBalance > transaction) {
							transactionBalance = currentUser.withdraw(userMap.get(fromClientUserName).userBalance, transaction);
							System.out.println("\t transaction amount entered" + transaction);
							mapToString(userMap.get(transactionUser.userName));
							transactionUser.userBalance = transactionBalance;

							userMap.put(fromClientUserName, transactionUser);
							mapToString(userMap.get(fromClientUserName));

							System.out.println("What user's account would you like to transfer to? Enter userName");
							toClientUserName = infoAccept.nextLine().toLowerCase().trim();
							// DEBUGGING
							System.out.println("\t" + toClientUserName + " toClientUserName entered but not entering usermap ");
							transactionUser = userMap.get(toClientUserName);
							transactionBalance = transactionUser.userBalance;// store client's balance in buffer
							transactionBalance += currentUser.deposit(userMap.get(currentUser.userName).userBalance,
									transaction);
							System.out.println(
									"\t transaction amount entered" + transaction + userMap.get(transactionUser.userName));
							transactionUser.userBalance = transactionBalance;
							userMap.put(currentUser.userName, transactionUser);
							mapToString(userMap.get(currentUser.userName));
						} else
							System.out.println("The transfer was not completed balance was lower than the transfer request");
					}
					if (userMap.get(currentUser.userName).userLevel == "customer") {
						mapToString(userMap.get(currentUser.userName));
						transactionUser = userMap.get(currentUser.userName);
						transactionBalance = transactionUser.userBalance;
						System.out.println("How much is the transaction?");
						amount = infoAccept.nextLine().toLowerCase().trim();
						transaction = Double.parseDouble(amount);
						transactionBalance = currentUser.withdraw(userMap.get(currentUser.userName).userBalance, transaction);
						System.out
						.println("\t transaction amount entered" + transaction + userMap.get(transactionUser.userName));
						transactionUser.userBalance = transactionBalance;
						userMap.put(currentUser.userName, transactionUser);
						mapToString(userMap.get(currentUser.userName));

						if (transactionBalance > transaction) {

							System.out.println("What user's account would you like to transfer to? Enter userName");
							toClientUserName = infoAccept.nextLine().toLowerCase().trim();
							// DEBUGGING
							System.out.println("\t" + toClientUserName + " toClientUserName entered but not entering usermap ");
							transactionUser = userMap.get(toClientUserName);
							transactionBalance = transactionUser.userBalance;// store client's balance in buffer
							transactionBalance += currentUser.deposit(userMap.get(currentUser.userName).userBalance,
									transaction);
							System.out.println(
									"\t transaction amount entered" + transaction + userMap.get(transactionUser.userName));
							transactionUser.userBalance = transactionBalance;
							userMap.put(currentUser.userName, transactionUser);
							mapToString(userMap.get(currentUser.userName));
						} else {
							System.out.println("The transfer was not completed balance was lower than the transfer request");

							break;
						}
					}
				case "c":
					// Debugging
					System.out.println("\t Selected c");
					if (userMap.get(currentUser.userName).userLevel == "admin") {
						mapToString(currentUser);
						System.out.println("What user's account would you like to cancel? Enter userName");
						clientUserName = infoAccept.nextLine().toLowerCase().trim();
						// DEBUGGING
						System.out.println("\t" + clientUserName + " clientUserName entered but not entering usermap ");
						transactionUser = userMap.get(clientUserName);
						transactionUser.userLevel = "cancelled";
						transactionUser.accountNo = 0000;
						transactionUser.userBalance = 000.00;
						transactionBalance = transactionUser.userBalance;// store client's balance in buffer
						userMap.put(clientUserName, transactionUser);
						mapToString(userMap.get(clientUserName));
					}
					break;

				case "v":
					// Debugging
					System.out.println("\t Selected v");
					mapToString(currentUser);
					for (String mapUserRecord : userMap.keySet()) {
						mapToString(userMap.get(mapUserRecord));
						// System.out.println("\n");
					}
					break;
				case "a":
					// Debugging
					System.out.println("\t Selected a");
					mapToString(currentUser);
					break;
				case "x":
					// Debugging
					System.out.println("\t Selected x");
					// mapToString(currentUser);
					System.exit(0);
					again = false;
					break;

				default:
					// System.exit(0);
					// code block
				}
			}while(again);
		}
	}
	
	
}
