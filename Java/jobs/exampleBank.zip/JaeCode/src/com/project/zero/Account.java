package com.project.zero;

import java.util.ArrayList;

public class Account {

	// fields
	private int acctId;
	private ArrayList<User> acctOwners;
	private double balance;
	
	private static int acctIdCounter;
	
	
	// constructors
	public Account() {
		super();
	}

	public Account(double balance) {
		super();
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "Account [acctId=" + acctId + ", acctOwners=" + acctOwners + ", balance=" + balance + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + acctId;
		result = prime * result + ((acctOwners == null) ? 0 : acctOwners.hashCode());
		long temp;
		temp = Double.doubleToLongBits(balance);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Account other = (Account) obj;
		if (acctId != other.acctId)
			return false;
		if (acctOwners == null) {
			if (other.acctOwners != null)
				return false;
		} else if (!acctOwners.equals(other.acctOwners))
			return false;
		if (Double.doubleToLongBits(balance) != Double.doubleToLongBits(other.balance))
			return false;
		return true;
	}

	public int getAcctId() {
		return acctId;
	}

	public void setAcctId(int acctId) {
		this.acctId = acctId;
	}

	public ArrayList<User> getAcctOwners() {
		return acctOwners;
	}

	public void setAcctOwners(ArrayList<User> acctOwners) {
		this.acctOwners = acctOwners;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public static int getAcctIdCounter() {
		return acctIdCounter;
	}
	
}
