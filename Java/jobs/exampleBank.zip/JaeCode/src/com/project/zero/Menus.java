package com.project.zero;

public class Menus {

	public void customerMenu() {
		System.out.println("Press:");
		System.out.println("w - to withdraw");
		System.out.println("d - to deposit");
		System.out.println("t - to transfer");
		System.out.println("x to Exit");
	}

	public void employeeMenu() {
		System.out.println("Press:");
		System.out.println("w - to withdraw");
		System.out.println("d - to deposit");
		System.out.println("t - to transfer");
		System.out.println("v - to view all customer information");
		System.out.println("a - to deny or approve an account");
		System.out.println("x to Exit");
	}

	public void adminMenu() {
		System.out.println("Press:");
		System.out.println("w - to withdraw");
		System.out.println("d - to deposit");
		System.out.println("t - to transfer");
		System.out.println("c - to cancel an account");
		System.out.println("v - to view all customer information");
		System.out.println("a - to deny or approve an account");
		System.out.println("x to Exit");
	}
}
