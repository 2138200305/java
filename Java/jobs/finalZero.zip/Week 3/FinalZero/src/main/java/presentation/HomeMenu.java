package presentation;

import util.InputProcessor;

public class HomeMenu implements Menu {

	//THIS IS THE FIRST SCREEN THE CUSTOMER SEES WHEN THEY START THE APPLICATION.
	public HomeMenu() {
		this.display();
	}
	@Override
	public LoginMenu display() {
		InputProcessor ip = InputProcessor.getInstance();

		int userSelection = ip.intPrompt(1, 2,
				"Welcome to WinWin Bank. " + "Where we win when you win!\n "
						+ "Press 1 if you if do not have a username and password, and want to apply for an account.",
				"Press 2 if you will enter your username and password");

		if (userSelection == 1) {

			new RegisterMenu();
		} else if (userSelection == 2) {
			new LoginMenu();

			// if userLevel == 2 send to wdt screen
			// if userLevel ==3 send to employee wdt+ view all screen
			// if userLevel ==4 send to approve and cancel account screen
		}
		return null;
	}
}
//		// TODO check if username exist in password && if password matches
//		// if Customer get Account associated with Customer
//		// if employee can select Account with username or Account No
//
//		//AppState.setActiveUser(new User("BakerI", "User", "Reverse321"));
//		int userChoice;
////        if (userLevel < 2) {
//		userChoice = ip.intPrompt(1, 3,
//				"Welcome " + AppState.getActiveUser().getUserName() + "!\nWhat would you like to do?\n0 to exit.",
//				"Withdraw", "Deposit", "Transfer", "From Which account");// need to cycle through accounts and get
//																			// selection
//		/*
//		 * TODO HERE IS AN EXAMPE OF ALLOWING HIGHER LEVEL USERS TO ACCESS CERTAIN
//		 * OPTIONS NOTE HOW THERE IS ADDITIONAL VAR ARGS ON THE SECOND LINE. THEY WILL
//		 * ONLY SEE OPTIONS YOU HAVE PROVIDED AND BY CONTROLLING THE NUMBERS THEY CAN
//		 * ENTER BY SETTING MIN AND MAX YOU ONLY HAVE TO USE 1 SWITCH STATEMENT.
//		 */
//		// } else {
//		// userChoice = ip.intPrompt(1, 4, "Welcome " +
//		// AppState.getActiveUser().getUserName() + "!\nWhat would you like to do?\n0 to
//		// exit.", "Withdraw", "Deposit", "Transfer", "Admin Options");
//		// }
//
//		while (true) {
//			switch (userChoice) {
//			case 1:
//				//serviceAccount.Withdraw(acc); // where do I save balance & input user settings
//				// TODO IMPLEMENT WITHDRAW LOGIC ON AppState.activeAccount.
//				break;
//			case 2:
//				//serviceAccount.Deposit(acc);
//				// TODO IMPLEMENT DEPOSIT LOGIC ON AppState.activeAccount.
//				break;
//			case 3:
//				ip.stringPrompt(1, 1,
//						"Please enter the username for the account that you would like to transfer the money to ");
//				Account tempTransfertoAccount = AppState.getActiveAccount(); // need to prompt for username to get
//																				// second account
//				//serviceAccount.Withdraw(acc); // take money from one account put into second
//				//serviceAccount.Deposit(tempTransfertoAccount);// do not show final balance
//
//				break;
//			case 0:
//				break;
//			}
//			return new HomeMenu();
//		}

