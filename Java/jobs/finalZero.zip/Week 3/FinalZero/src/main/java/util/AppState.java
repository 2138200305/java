package util;

import models.Account;
import models.User;

public class AppState {
    private static User activeUser;

    private static Account activeAccount;

    public static User getActiveUser() {
        return activeUser;
    }

    public static void setActiveUser(User activeUser) {
        AppState.activeUser = activeUser;
    }

    public static Account getActiveAccount() {
        return activeAccount;
    }

    public static void setActiveAccount(Account activeAccount) {
        AppState.activeAccount = activeAccount;
    }
}
