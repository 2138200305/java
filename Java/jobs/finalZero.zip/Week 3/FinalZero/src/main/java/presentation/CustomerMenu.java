package presentation;

import models.Account;
import models.User;
import util.AppState;
import util.InputProcessor;

public class CustomerMenu implements Menu {
	Account tempAccount = AppState.getActiveAccount();
	service.AccountServices serviceAccount;
	
	
    public static void main(String[] args) {
        new CustomerMenu();
    }
    @Override
    public Menu display() {
    	Account acc = AppState.getActiveAccount();
        InputProcessor ip = InputProcessor.getInstance();
        int userChoice;
//        if (userLevel < 2) {
            userChoice = ip.intPrompt(1, 3, "Welcome " + AppState.getActiveUser().getUserName() + "!\nWhat would you like to do?\n0 to exit.", "Withdraw", "Deposit", "Transfer");
            /* TODO HERE IS AN EXAMPE OF ALLOWING HIGHER LEVEL USERS TO ACCESS CERTAIN OPTIONS
                NOTE HOW THERE IS ADDITIONAL VAR ARGS ON THE SECOND LINE. THEY WILL ONLY SEE
                OPTIONS YOU HAVE PROVIDED AND BY CONTROLLING THE NUMBERS THEY CAN ENTER BY
                SETTING MIN AND MAX YOU ONLY HAVE TO USE 1 SWITCH STATEMENT.
             */
            //        } else {
            //userChoice = ip.intPrompt(1, 4, "Welcome " + AppState.getActiveUser().getUserName() + "!\nWhat would you like to do?\n0 to exit.", "Withdraw", "Deposit", "Transfer", "Admin Options");
        //}

        while (true) {
            switch (userChoice) {
                case 1:
               //needs to unput user or account # 	
                	serviceAccount.Withdraw(acc); // where do I save balance & input user settings
                break;
                case 2:
                	serviceAccount.Deposit(acc);
                    //TODO IMPLEMENT DEPOSIT LOGIC ON AppState.activeAccount.
                    break;
              case 3:
            		ip.stringPrompt(1, 1,
    						"Please enter the username for the account that you would like to transfer the money to ");
    				Account tempTransfertoAccount = AppState.getActiveAccount(); // need to prompt for username to get
    																				// second account
    				serviceAccount.Withdraw(acc); // take money from one account put into second
    				serviceAccount.Deposit(tempTransfertoAccount);//do not show final balance 
                  //TODO THIS WILL REQUIRE IT'S OWN TRANSFER SCREEN.
                    break;
                case 0:
                    break;
            }
            return new HomeMenu();
        }
    }

    public CustomerMenu() {
        this.display();
    }

}
