package service;

import models.Account;
import models.User;
import util.AppState;
import util.InputProcessor;

public class AccountServices {
	Account acc = new Account(21, 500);// testAccount

	/*
	 * TODO Add a method of changing a particular Users userLevel attribute. Call
	 * the method from the UserDAO that will update the particular user in question.
	 * Something like
	 */
	// TODO Add a method which c

	private double roundDollar(double amount) {
		double scale = Math.pow(10, 2);
		return Math.round(amount * scale) / scale;
	}

	public void Deposit(Account acc) {
		InputProcessor ip = new InputProcessor();

		double amount = ip.doublePrompt(0, 10000, "How much would you like to deposit\nEnter a 0 to exit.");
		amount = roundDollar(amount);
		if (amount == 0) {
			return;
		} else {
			acc.setBalance(acc.getBalance() + amount);
			System.out.println(acc.getBalance());
		}
	}

	public void Withdraw(Account acc ) {
		InputProcessor ip = new InputProcessor();


		// TODO once is AccountDOA is working replace dummy data w/ data
		// from AccountDOA
		double amount = ip.doublePrompt(0, 10000, "How much would you like to deposit\nEnter a 0 to exit.");
		amount = roundDollar(amount);
		if ((acc.getBalance() - amount) > 0) {
			if (amount == 0) {
				return;
			} else {
				acc.setBalance(acc.getBalance() - amount);
				System.out.println(acc.getBalance());
			}
		} else {
			System.out.println("Invalid withdraw amount greater than balance");

		}

	}

	//employee or admin user lever
	public void listUsers(Account acc) {
					for (User u : AppState.getActiveAccount().getAllUsers())
						System.out.println(u.toString());
		
				}

		
	}
