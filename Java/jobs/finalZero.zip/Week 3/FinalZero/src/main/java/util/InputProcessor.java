package util;

import java.util.Scanner;

public class InputProcessor {

// ================FIELDS==================

// ================CONSTRUCTORS==================

    private static InputProcessor ip;

    // private constructor to force use of
    // getInstance() to create Singleton object

    public static InputProcessor getInstance()
    {
        if (ip ==null)
            ip = new InputProcessor();
        return ip;
    }


    // ================BEHAVIORS==================
    private String readConsole() {
        return new Scanner(System.in).nextLine();
    }

    private int askForInt(int min, int max) {
        while (true) {
            try {
                int returnVar = Integer.parseInt(readConsole());
                if (returnVar < min || returnVar > max){
                    System.out.println("Out of range. Entry must be between " + min + " and " + max);
                    continue;}
                return returnVar;
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number.");
            }
        }
    }

    private double askForDouble(double min, double max) {
        while (true) {
            try {
                double returnVar = Double.parseDouble(readConsole());
                if (returnVar < min || returnVar > max){
                    System.out.println("Out of range. Entry must be between " + min + " and " + max);
                    continue;
                }
                return returnVar;
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number.");
            }
        }
    }
    private String askForString(int min, int max) {
        while (true) {
                String returnVar = readConsole();
                if (returnVar.length() < min || returnVar.length() > max) {
                    System.out.println("Out of range. Entry must be between " + min + " and " + max + " characters in length.");
                    continue;
                } else {
                    return returnVar;
                }
        }
    }

    //Talk to user
    public String stringPrompt(int minLength, int maxLength, String... prompt) {
    //present prompt to the user
        printPrompt(prompt);
        return askForString(minLength, maxLength);
    }
    //Talk to user
    public int intPrompt(int min, int max, String... prompt) {
        //present prompt to the user
        printPrompt(prompt);
        return askForInt(min, max);
    }

    public double doublePrompt(double min, double max, String... prompt) {
        //present prompt to the user
        printPrompt(prompt);
        return askForDouble(min, max);
    }

    private void printPrompt (String...prompt){
            System.out.println("============================");
        for(int i =0; i<prompt.length; i++ ){
            //present zero index in prompt differently than the rest of prompt
            if (i == 0) System.out.println(prompt[0]);
            if(i != 0) System.out.println(i + ". " + prompt[i]);


    }






    }


}

// ================OVERRIDE METHODS==================


// ================GETTERS AND SETTERS==================
