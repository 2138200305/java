package presentation;

import data.UserDAO;
import util.AppState;
import util.InputProcessor;

public class LoginMenu implements Menu {

	public LoginMenu() {
		this.display();
	}
    public Menu display() {
        InputProcessor ip = InputProcessor.getInstance();
        String tempUserName = ip.stringPrompt(6, 25, "Welcome please enter your username");
        //use userDAO to check if tempUser can be found in db
        
           // AppState.setActiveUser(new User("BakerI", "customer", "password321"));
        	UserDAO ud = UserDAO.getInstance();
        	AppState.setActiveUser(ud.getByUserName(tempUserName));
        	System.out.println(AppState.getActiveUser().getUserName());
        int counter = 0;
        while (true) {
            String tempPassword = ip.stringPrompt(6, 25, "Please enter your password");
            if (AppState.getActiveUser().getPassword().equals(tempPassword)) {
            	System.out.println("Password accepted");
            	
                return new DashBoardMenu();
            } else {
                if (counter < 3) {
                    System.out.println("Invalid password. Please try again.");
                    counter++;
                } else {
                    System.out.println("Too many attempts.  System will now exit.");
                    return null;
                }
            }
        }
    }
}