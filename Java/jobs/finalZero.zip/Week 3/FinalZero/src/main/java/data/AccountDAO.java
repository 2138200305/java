package data;

public class AccountDAO {

    private static AccountDAO ad;

    // private constructor to force use of
    // getInstance() to create Singleton object

    public static AccountDAO getInstance()
    {
        if (ad ==null)
            ad = new AccountDAO();
        return ad;
    }
//TODO method to get ALL accounts


//TODO method to get all accounts for AppState.activeUser()
// TODO method to update AppState.activeAccount
}
