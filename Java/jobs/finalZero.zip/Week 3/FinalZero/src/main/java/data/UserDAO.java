package data;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.ArrayList;
import java.util.List;

import models.User;


public class UserDAO {

	private static UserDAO ud;

	// private constructor to force use of
	// getInstance() to create Singleton object

	public static UserDAO getInstance() {
		if (ud == null)
			ud = new UserDAO();
		return ud;
	}

public User getByUserName(String userName) {
	
	List<User> users = sqlPrepRequest(null, userName,"SELECT * FROM bankuser WHERE user_name = ?");
	System.out.println(users.size());
	return users.get(0); 
}
	
	
	private List<User> sqlPrepRequest(User user, String noUser, String sql) {
        List<User> users = null;
        try (Connection conn = ConnectionFactory.getInstance().getConnection()) {

            conn.setAutoCommit(false);

           PreparedStatement pstmt = conn.prepareStatement(sql);
            //e.g. sql may be "SELECT * FROM users WHERE username = ?"
 
//            if (user != null && noUser == null) {
//                pstmt.setString(1, user.getUserName());
//                pstmt.setString(2, user.getUserLevel());
//                pstmt.setString(3, user.getPassword());
//                pstmt.setString(4, user.getUserFirstName());
//                pstmt.setString(5, user.getUserLastName());
//            } else if (user == null && noUser != null) {
                
           pstmt.setString(1,noUser);
            //}

            pstmt.execute(); //This is where our SQL statement actually fires.

            if (pstmt.executeUpdate() != 0) conn.commit();

            users = mapResultSet(pstmt.executeQuery());

        } catch (SQLIntegrityConstraintViolationException sicve) {
            System.out.println("SQL INTEGRITY EXCEPTION");
        } catch (SQLException e) {
            System.out.println("SQL GENERIC EXCEPTION");
        }
        return users;
    }
	
	
	private List<User> mapResultSet(ResultSet rs) throws SQLException {
		List<User> returnVar = new ArrayList<User>(); {
		};
		
		while (rs.next()) {
			String userName = rs.getString(1);
			String password = rs.getString(2);
			String userFirstName = rs.getString(3);
			String userLastName = rs.getString(4);
			String userLevel = rs.getString(5);
			returnVar.add(new User(userName, password, userFirstName, userLastName, userLevel));
		}
		return returnVar;
	}
}
