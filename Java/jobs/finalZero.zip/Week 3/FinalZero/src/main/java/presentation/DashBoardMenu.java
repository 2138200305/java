package presentation;

import models.User;
import util.AppState;

public class DashBoardMenu implements Menu {

	public DashBoardMenu() {
		this.display();
	}

	@Override
	public LoginMenu display() {
		System.out.println("Welcome to the Dashboard");
		// Debuggin
		User activeUser = AppState.getActiveUser();
		// AppState.getActiveUser().toString();
		// if(activeUser.getUserLevel().equals("customer")) {

		switch (activeUser.getUserLevel()) {

		case "customer":
			// TODO create a prompt to allow us to W, D, T
			// This prompt should have a min of 0 and max of 3
			// The var args for this prompt should only have withdrawl and D and T as
			// options

			// }else if ((activeUser.getUserLevel().equals(("employee") ||
			// (activeUser.getUserLevel().equals(("admin"))
		case "employee":

			// TODO create a for employees/admin prompt to allow us V, C, A
		case "admin":
			// This prompt should have a min of 0 and max of 6
			// The var args should have all options

			// Create switch case with options with options for WTDCAV
			
			//admin user 


		}
		return null;
	}
}
