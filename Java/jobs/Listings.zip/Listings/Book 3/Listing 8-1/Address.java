package com.lowewriter.payroll;

public class Address implements Cloneable
{
	public String street;
	public String city;
	public String state;
	public String zipCode;
}