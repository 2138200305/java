package com.lowewriter.movie;

public class Movie
{
    public String title;
    public int year;
    public double price;
    public Movie(String title, int year, 
                 double price)
    {
        this.title = title;
        this.year = year;
        this.price = price;
    }
}
