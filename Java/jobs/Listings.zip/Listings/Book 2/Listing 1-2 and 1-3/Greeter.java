// This class creates a Greeter object
// that displays a hello message on
// the console.

public class Greeter	
{
    public void sayHello()	
    {
        System.out.println("Hello, World!");
    }
}
