package com.example.controller;

import javax.servlet.http.HttpServletRequest;

public class RequestHelper {

	public static String process(HttpServletRequest request) {

		System.out.println(request.getRequestURI());
		
		switch (request.getRequestURI()) {
		case "/HelloFrontController/login.michael":
			System.out.println("in login.do requesthelper");
			return LoginController.login(request);
		case "/HelloFrontController/home.michael":
			System.out.println("in home.do requesthelper");
			return HomeController.home(request);
		default:
			/*return "login.michael";*/
			return "resources/html/unsuccessfullogin.html";
		}
	}
}
