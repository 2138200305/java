package com.example.controller;

import javax.servlet.http.HttpServletRequest;

public class HomeController {
	public static String home(HttpServletRequest request) {
		
		//after the login.michael was trigger we can access the session variables
		// anywhere in the server
		System.out.println(request.getSession().getAttribute("loggedpassword"));
		
		return "resources/html/home.html";
	}
}
