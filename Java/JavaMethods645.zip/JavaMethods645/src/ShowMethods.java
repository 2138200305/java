
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author dehkhoda_abbas
 */
public class ShowMethods 
{
    public static void main(String [] args)
    {
        Scanner input = new Scanner(System.in);
        justRead(input);
        
        Scanner xx = giveMeScanner();
        
        System.out.println("input == xx >>" + (xx == input));
        
        for(int i=0; i < 20 ; i++)
        {
         System.out.println(getRandom(100,999));
        }
        System.exit(0);
    }
    
        public static void justRead(Scanner x)
        {
          System.out.print( "enter String:");  
          String out = x.nextLine();
          System.out.println("=====>>>"+out);
        }
    
       public static Scanner giveMeScanner()
       {
         return  new Scanner(System.in);
           
       }
    
    
    
    public static int getRandom(int low, int high)
    {
        
        return (int)(Math.random()*(high-low+1)) + low;
    }
    
    
    public static int giveMeNumberBetween6and89()
    {
        return (int)(Math.random()*(89-6+1)) + 6;
        
    }
    
}
